
(function() {
    'use strict';
    /*jshint esnext: true */

    let text = document.querySelectorAll('p').textContent;
    if (text)
        console.log(text);
})();
