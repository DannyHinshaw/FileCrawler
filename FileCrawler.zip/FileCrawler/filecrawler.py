import os, sys
import re


def edit(x, t, r):

    print(x)
    global file_data

    with open(x, 'r') as file:
        file_data = file.read()

    file_data = re.sub(t, r, file_data)

    with open(x, 'w') as file:
        file.write(file_data)


def restart():
    script = sys.executable
    os.execl(script, script, * sys.argv)


def start():
    path = input('Enter File Directory to crawl: ')
    file_types = input('File types to edit? (Separate by commas ex. .html, .css): ').replace(" ", "").split(",")

    if '.html' in file_types:
        user_input = input('WARNING: Parsing html with regex may give unexpected results. Continue? (y/n): ')
        if user_input.lower() in 'no':
            user_input = input('Would you like to exit (e) or restart (r) the script? (e/r): ')
            if len(user_input.lower()) > 2 and user_input.lower() in 'restart':
                restart()
            else:
                sys.exit()

    target = re.escape(input('Enter Regex for string to replace: '))
    replacement = input('Enter replacement string: ')

    for root, dirs, files in os.walk(path):
        [edit(os.path.join(root, name), target, replacement) for name in files for ft in file_types if ft in name]

if __name__ == "__main__":
    start()